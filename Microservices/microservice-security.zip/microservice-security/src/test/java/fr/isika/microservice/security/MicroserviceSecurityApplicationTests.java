package fr.isika.microservice.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
