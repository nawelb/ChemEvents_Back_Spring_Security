package fr.isika.microservice.evenement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceEvenementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceEvenementApplication.class, args);
	}

}
