package fr.isika.microservice.evenement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceEvenementApplicationTests {

	@Test
	void contextLoads() {
	}

}
